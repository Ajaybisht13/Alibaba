import { combineReducers } from "redux";
import filterItem from "./reducers";

export default combineReducers({
    filterItem,
});