export const baseUrl = "http://uatjiffygifts.nubiz.co.in/api/v1/";

// export const baseUrl = "http://apijiffygifts.nubiz.co.in/api/v1/";